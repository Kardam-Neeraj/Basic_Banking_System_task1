<!-- navbar --> 
      <nav class="navbar navbar-expand-md navbar-light bg-light">
      <img src="img/logo_small.png" width="30" height="30"  >
      <a class="navbar-brand" href="index.php" > The Sparks Foundation</a>
      
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar" style="background-color:#044553;">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php" style="color: white;">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="viewcustomers.php" style="color: white;">View Customers</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transfer.php" style="color: white;">Transfer Money</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="transactionhistory.php" style="color: white;">Transaction Record</a>
              </li>
          </div>
       </nav>
